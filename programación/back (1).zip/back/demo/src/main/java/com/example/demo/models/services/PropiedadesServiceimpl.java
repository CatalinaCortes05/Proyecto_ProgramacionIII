package com.example.demo.models.services;


import com.example.demo.models.entity.Propiedades;
import com.example.demo.models.repository.IPropiedadesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PropiedadesServiceimpl implements IPropiedadesService{
    @Autowired
    private IPropiedadesRepository propiedadesRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Propiedades> findAll() {
        return (List<Propiedades>) propiedadesRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Propiedades findById(Long id) {
        return propiedadesRepository.findById(id).orElse(null);
    }


    @Override
    @Transactional
    public Propiedades save(Propiedades propiedades) {
        return propiedadesRepository.save(propiedades);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        propiedadesRepository.deleteById(id);
    }
}


