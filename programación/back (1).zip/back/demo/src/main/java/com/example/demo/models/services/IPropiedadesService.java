package com.example.demo.models.services;

import com.example.demo.models.entity.Propiedades;

import java.util.List;

public interface IPropiedadesService {

    public List<Propiedades> findAll();

    public Propiedades findById(Long id);

    public Propiedades save(Propiedades propiedades);

    public void delete(Long id);
}
