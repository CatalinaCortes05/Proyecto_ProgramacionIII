package com.example.demo.controllers;

import com.example.demo.models.entity.Propiedades;
import com.example.demo.models.services.IPropiedadesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("/api")
public class PropiedadesRestController {
    @Autowired
    private IPropiedadesService propiedadesService;

    @GetMapping("/propiedades")
    public List<Propiedades> index() {
        return propiedadesService.findAll();
    }

    @GetMapping("/propiedades/{id}")
    public Propiedades show(@PathVariable Long id) {
        return propiedadesService.findById(id);
    }

    @PostMapping("/propiedades")
    @ResponseStatus(HttpStatus.CREATED)
    public Propiedades create(@RequestBody Propiedades propiedades) {
        return propiedadesService.save(propiedades);
    }

    @PutMapping("/propiedades/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public Propiedades update(@RequestBody Propiedades propiedades, @PathVariable Long id) {
        Propiedades propiedadesActual = propiedadesService.findById(id);
        propiedadesActual.setDireccion(propiedades.getDireccion());
        propiedadesActual.setTipo(propiedades.getTipo());
        propiedadesActual.setPrecio(propiedades.getPrecio());

        return propiedadesService.save(propiedadesActual);
    }

    @DeleteMapping("/propiedades/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        propiedadesService.delete(id);
    }
}
